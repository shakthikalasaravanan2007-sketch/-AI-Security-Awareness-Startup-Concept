# ShieldWise — AI Security Awareness Startup Concept

ShieldWise is a responsive front-end startup concept for helping students, families, and small businesses build safer digital habits.

## Features
- Startup landing page describing the problem, solution, target audience, and illustrative business model.
- Five interactive lessons: phishing, passwords, multi-factor authentication, software updates, and personal information.
- Five-question scenario-based quiz with feedback.
- Lesson progress saved in browser `localStorage`.
- Responsive desktop and mobile design.
- No backend, account, API key, or installation required.

## Important scope note
This is an educational prototype, not a registered company or commercial security product. The current tutor content is static and rule-based; no generative AI service is connected. Business plans are illustrative ideas, not actual subscriptions.

## Run locally
Open `index.html` in a modern browser. Alternatively run `python -m http.server 8000` in this folder and visit `http://localhost:8000`.

## Publish with GitHub Pages
1. Create a repository such as `shieldwise-security-awareness`.
2. Upload all project files to the repository root.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, branch `main`, folder `/(root)`, then save.
5. Wait for GitHub Pages to publish the site.

## Project structure
- `index.html` — page structure
- `style.css` — responsive styling
- `script.js` — lessons, quiz, progress tracking
- `README.md` — project guide
- `LICENSE` — MIT license
- `.gitignore` — editor and OS exclusions

## Future improvements
- Add a real AI tutor through a secure backend; never expose private API keys in browser JavaScript.
- Add consent-based educator dashboards and privacy-conscious reporting.
- Add more languages and accessibility options.
- Add a content management system for lesson updates.

## Safety
This project teaches defensive awareness. It is not a security scanner. Report suspicious activity through appropriate official channels.

## License
Project source code is provided under the MIT License. ShieldWise is a fictional project name for this educational prototype.
